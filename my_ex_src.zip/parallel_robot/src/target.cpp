#include <ros/ros.h>
#include <tf/transform_broadcaster.h>



int main(int argc, char** argv)
{
  ros::init(argc, argv, "target");

  ros::NodeHandle nh_glob;

  tf::TransformBroadcaster targetBradcaster;

  const double r = 3;

  const double x = 1;

  ros::Rate targetFrameRate(100) ;

  const double t0 =  ros::Time::now().toSec();

  double t;

  while(ros::ok()) {

    t = ros::Time::now().toSec() - t0;

    tf::Transform target_tf;

    target_tf.setOrigin( tf::Vector3( x, r*sin(M_PI*t/3), 0));
    tf::Quaternion q;
    q.setRPY(0.0, 0.0, 0.0);
    target_tf.setRotation(q);



    targetBradcaster.sendTransform(tf::StampedTransform(target_tf, ros::Time::now(), "base", "goal"));

    targetFrameRate.sleep();

  }
}
