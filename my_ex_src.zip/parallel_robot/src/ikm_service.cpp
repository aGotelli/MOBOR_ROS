#include <ros/ros.h>
#include <tf/transform_listener.h>
#include <sensor_msgs/JointState.h>


#include <math.h>




int main(int argc, char** argv)
{
  ros::init(argc, argv, "ikm_node");

  ros::NodeHandle glob_nh;

  // Declare your node's subscriptions and service clients
  tf::TransformListener gotGoal_tf;

  ros::Publisher pubJointCommands = glob_nh.advertise<sensor_msgs::JointState>("/joint_states")

  const double a = 2;
  const double length = 1;

  while(ros::ok()) {
    ros::spinOnce();


    tf::StampedTransform transform;

    //  Try to catch data from the tf
    try{
      gotGoal_tf.lookupTransform("base", "goal", ros::Time(0), transform);
    }
    catch (tf::TransformException ex){
      ROS_ERROR("%s",ex.what());
      ros::Duration(1.0).sleep();
    }

    const double x = transform.getOrigin().x();
    const double y = transform.getOrigin().y();

    if((2*length)*(2*length) > x*x + y*y &&
        (2*length)*(2*length) > (a - x)*(a - x) + y*y  ) {

          const double q1 = atan2(y, x);
          const double q2 = M_PI - atan2(y, x);

          const double d1 = sqrt( x*x + y*y);
          const double d1 = sqrt( (a - x)*(a - x) + y*y);

        }




  }
}
