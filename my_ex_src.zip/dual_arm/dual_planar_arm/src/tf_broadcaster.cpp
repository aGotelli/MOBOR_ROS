/**
 * \file ft_broadcaster.cpp
 * \brief broadcast in a general way
 * \author Andrea Gotelli
 * \version 0.1
 * \date 04/05/2020
 *
 * \param[in]
 *
 * Subscribes to: <BR>
 *    °
 *
 * Publishes to: <BR>
 *    ° /tf
 *
 * Description
        This node just publish the transformation from the left elbow to the goal
        but in a general way
 *
 */


//Cpp
#include <sstream>
#include <stdio.h>
#include <vector>
#include <iostream>
#include <stdlib.h>
#include <math.h>

//ROS
#include "ros/ros.h"
#include <tf/transform_broadcaster.h>



int main (int argc, char** argv)
{

	//ROS Initialization
    ros::init(argc, argv, "tf_broadcaster");

    // Define your node handles: YOU NEED AT LEAST ONE !
    ros::NodeHandle nh_glob ;

    //broadcaster declaration
    tf::TransformBroadcaster br;

    // declaration of the transform
    tf::Transform transform;

    //initialize the traslational part of the transformation
    transform.setOrigin( tf::Vector3(1, 0, 0) );

    //set the quaterinon
    tf::Quaternion q;
    q.setRPY(0, 0, 0);

    //use the quaterinon to set the null rotation
    transform.setRotation(q);


    ros::Rate rate(50);   // Or other rate.
    while (ros::ok()){
        ros::spinOnce();

        br.sendTransform(tf::StampedTransform(transform, ros::Time::now(), "l_forearm", "goal"));

        rate.sleep();
    }
}
