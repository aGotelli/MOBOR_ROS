/**
 * \file track left arm
 * \brief this node is the bridge from the left arm to the right arm
 * \author Andrea Gotelli
 * \version 0.1
 * \date 04/05/2020
 *
 * \param[in]
 *
 * Subscribes to: <BR>
 *    ° /tf [reads the published tf transform]
 *    ° /right_arm_IK_service, absolute topic name.
 *
 * Publishes to: <BR>
 *    °
 *
 * Description
          here the goal is to create a node that subscribes to the tf transform
          that is the goal frame defined in the tf_broadcaster. The information
          about the poistion of the goal frame are used to compute the joint values
          for the right arm in order to reach the goal (if possible)
 *
 */


//Cpp
#include <sstream>
#include <stdio.h>
#include <vector>
#include <iostream>
#include <stdlib.h>
#include <math.h>

//ROS
#include "ros/ros.h"

// Include here the ".h" files corresponding to the topic type you use.
#include <tf/transform_listener.h>
#include <dual_planar_arm_msgs/DualArmIK.h>
#include <sensor_msgs/JointState.h>

int main (int argc, char** argv)
{

	//ROS Initialization
    ros::init(argc, argv, "left_arm_tracker");

    // Define your node handles: YOU NEED AT LEAST ONE !
    ros::NodeHandle nh_glob, nh_loc("~") ;

    // Declare your node's subscriptions and service clients
    tf::TransformListener gotGoal_tf;

    //  Declaration of the service client
    ros::ServiceClient IKclient = nh_glob.serviceClient<dual_planar_arm_msgs::DualArmIK>("/right_arm_IK_service");

    //  declaration of the service message
    dual_planar_arm_msgs::DualArmIK IKproblem;
    //IKproblem.request.goal.header.frame_id = "r_arm_base";

    // Declare your publishers here.
    ros::Publisher pubJointCommands = nh_glob.advertise<sensor_msgs::JointState>("/joint_command", 1) ;


    ros::Rate rate(50);   // Or other rate.
    bool condition = false;

    while (ros::ok()){
        ros::spinOnce();

        // Declaration of the stamped transform
        tf::StampedTransform transform;

        //  Try to catch data from the tf
        try{
          //  Here there is the listener taking the data from the transform and saving them
          //  into "transform "
          gotGoal_tf.lookupTransform("r_arm_base", "goal",
                                    ros::Time(0), transform);
        }
          //  If there are problems it throws error
        catch (tf::TransformException ex){
          ROS_ERROR("%s",ex.what());
          ros::Duration(1.0).sleep();
        }

        //  Initialization of the service request
        IKproblem.request.goal.header.frame_id = "r_arm_base";
        IKproblem.request.goal.point.x = transform.getOrigin().x();
        IKproblem.request.goal.point.y = transform.getOrigin().y();

        if(!IKclient.exists() 	)
          continue;   //  No reason to go on if the server does not exist, so skip this loop iteration

        if (!IKclient.call(IKproblem))
        {
          ROS_ERROR("Failed to call service ");
          continue;   //  No reason to go on if the call did not success, so skip this loop iteration
        }

//====== Reaching this step of the loop means there are no problem neither in the service, nor in the call ======

        //  If the response in not empty, the right robot should move
        if( IKproblem.response.solutions.size() ) {

          // The following is just a bunch of screen information for debug
          ROS_INFO_STREAM("Number of solution(s) : " << IKproblem.response.solutions.size() );
          for(const auto sol : IKproblem.response.solutions) {
            for(int i=0; i < sol.name.size(); i++) {
              ROS_INFO_STREAM("Name : " << sol.name[i] << ", Value : " << sol.position[i]*180/M_PI);
            }
          }

          //  At this point is possible to set the joint command

          //  The sensor_msgs::JointState structure

          // std_msgs/Header header
          //   uint32 seq
          //   time stamp
          //   string frame_id
          // string[] name
          // float64[] position
          // float64[] velocity
          // float64[] effort



          sensor_msgs::JointState jointCommand = IKproblem.response.solutions[0];
          //  Now publish the command
          pubJointCommands.publish( jointCommand );

          /*
          Here the JointState object is declared in the while loop. The reason is because the
          name and poistion array must have the same size. If declaration is outside the loop,
          then it is necessary to clear the name array after having pubished each time.

          It is simply more convenient to declare the object here. Alsothe Initialization
          is the simple copy of the message that has been received as the servide response.
          This initialization is possible because it exists inside the if scope (that check the
          existence of at least one solution)


          pubJointCommands.publish( IKproblem.response.solutions[0] );
          */

        }


        rate.sleep();
    }
}
