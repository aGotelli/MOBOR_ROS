/**
 * \file
 * \brief
 * \author
 * \version 0.1
 * \date
 *
 * \param[in]
 *
 * Subscribes to: <BR>
 *    °
 *
 * Publishes to: <BR>
 *    °
 *
 * Description
 *
 */


//Cpp
#include <sstream>
#include <stdio.h>
#include <vector>
#include <iostream>
#include <stdlib.h>
#include <math.h>

//ROS
#include "ros/ros.h"

#include "std_msgs/Int16.h"
#include <geometry_msgs/PointStamped.h>
#include <nav_msgs/Path.h>
#include <geometry_msgs/Twist.h>

#include "visualization_msgs/Marker.h"

void Callback1(geometry_msgs::Twist)
{

}

void Callback2(geometry_msgs::PointStamped)
{

}


int main (int argc, char** argv)
{

	//ROS Initialization
    ros::init(argc, argv, "Put the node default name here");

    ros::NodeHandle nh_glob;

    ros::Subscriber PathToFollow = nh_glob.subscribe("TwistToRobot", 1, Callback1);
    ros::Publisher robotPose = nh_glob.advertise<geometry_msgs::Point>("RobotPosition", 1);
    ros::Publisher robotgeneral = nh_glob.advertise<geometry_msgs::Point>("/RobotGenerealizedCoordinates", 1);
    ros::Publisher marker = nh_glob.advertise<visualization_msgs::Marker>("/visualization_marker", 1);


    ros::Rate rate(10);   // Or other rate.
    while (ros::ok()){
        ros::spinOnce();


        rate.sleep();
    }
}
