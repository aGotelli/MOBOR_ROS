/**
 * \file
 * \brief
 * \author
 * \version 0.1
 * \date
 *
 * \param[in]
 *
 * Subscribes to: <BR>
 *    °
 *
 * Publishes to: <BR>
 *    °
 *
 * Description
 *
 */


//Cpp
#include <sstream>
#include <stdio.h>
#include <vector>
#include <iostream>
#include <stdlib.h>
#include <math.h>

//ROS
#include "ros/ros.h"

#include "std_msgs/Int16.h"
#include <geometry_msgs/PoseWithCovarianceStamped.h>
#include <nav_msgs/Path.h>

#include "visualization_msgs/Marker.h"

void Callback1(std_msgs::Int16 key)
{

}

void Callback2(geometry_msgs::PoseWithCovarianceStamped point)
{

}

void Callback2(nav_msgs::Path path )
{

}


int main (int argc, char** argv)
{

	//ROS Initialization
    ros::init(argc, argv, "Put the node default name here");

    ros::NodeHandle nh_glob;

    ros::Publisher PathToFollow = nh_glob.advertise<nav_msgs::Path>("/PathToFollow", 1);
    ros::Publisher PathToSmooth = nh_glob.advertise<nav_msgs::Path>("PathToSmooth", 1);
    ros::Publisher marker = nh_glob.advertise<visualization_msgs::Marker>("/visualization_marker", 1);
    ros::Subscriber smothed = nh_glob.subscribe<nav_msgs::Path>("PathSmoothed", 1, Callback2);
    ros::Subscriber KeySub = nh_glob.subscribe<std_msgs::Int16>("/KeyTyped",1,Callback1) ;
    ros::Subscriber PoseSub = nh_glob.subscribe<geometry_msgs::PoseWithCovarianceStamped>("/initialpose",1,Callback2) ;



    visualization_msgs::Marker points, line;

    ros::Rate rate(10);   // Or other rate.
    while (ros::ok()){
        ros::spinOnce();

        marker.publish(points);
        marker.publish(line);


        rate.sleep();
    }
}
