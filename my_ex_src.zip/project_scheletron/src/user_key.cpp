/**
 * \file
 * \brief
 * \author
 * \version 0.1
 * \date
 *
 * \param[in]
 *
 * Subscribes to: <BR>
 *    °
 *
 * Publishes to: <BR>
 *    °
 *
 * Description
 *
 */


//Cpp
#include <sstream>
#include <stdio.h>
#include <vector>
#include <iostream>
#include <stdlib.h>
#include <math.h>

//ROS
#include "ros/ros.h"

#include "std_msgs/Int16.h"



int main (int argc, char** argv)
{

	//ROS Initialization
    ros::init(argc, argv, "Put the node default name here");

    ros::NodeHandle nh_glob;

    ros::Publisher pubKey = nh_glob.advertise<std_msgs::Int16>("/KeyTyped", 1);

    std_msgs::Int16 num;

    ros::Rate rate(10);   // Or other rate.
    while (ros::ok()){
        ros::spinOnce();

        pubKey.publish(num);
        rate.sleep();
    }
}
