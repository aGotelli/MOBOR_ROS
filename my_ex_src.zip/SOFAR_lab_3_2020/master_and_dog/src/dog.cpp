/**
 * \file dog contains the code for let a dog to follow a master
 * \brief
 * \author Andrea Gotelli
 * \version 0.1
 * \date  27/04/2020
 *
 * \param[in]
 *    ° x_init
 *    ° y_init
 *
 * Subscribes to: <BR>
 *    ° MasterPosition
 *    ° MasterVelocity
 *
 * Publishes to: <BR>
 *    ° visualization_marker
 *    ° DogVelocity
 *    ° DogPosition
 *
 * Description
 *        In this version the dog changes its initial position accordingly with
          the parameters given in the launch file. The dafault poistion is
          [0 0 0]. This uses the same callbacks and flags as before.
 */


//Cpp
#include <sstream>
#include <stdio.h>
#include <vector>
#include <iostream>
#include <stdlib.h>
#include <math.h>
#include <eigen3/Eigen/Dense>         //easy vector operations


//ROS
#include "ros/ros.h"

// Include here the ".h" files corresponding to the topic type you use.
#include "geometry_msgs/Point.h"
#include "std_msgs/Float64.h"
#include "visualization_msgs/Marker.h"

// You may have a number of globals here.
ros::Publisher pubMarker ;
visualization_msgs::Marker marker;

geometry_msgs::Point dogPose;
Eigen::VectorXd B(2), A(2), BA(2);
bool CalculateDirCalled = false;

double speed;
bool UpdateSpeedCalled = false;

// Callback functions...

// CallBack for master position
void CalculateDir(const geometry_msgs::Point::ConstPtr& masterPose)
{

  B(0) = masterPose->x;
  B(1) = masterPose->y;

  if(!CalculateDirCalled)
    CalculateDirCalled = true;
}


// CallBack for master speed
void UpdateSpeed(const std_msgs::Float64::ConstPtr& masterSpeed)
{
  speed = masterSpeed->data;

  if(!UpdateSpeedCalled)
    UpdateSpeedCalled = true;
}


void initializeMarker(){
    // Fetch node name. Markers will be blue if the word "blue" is in the name, red otherwise.
    std::string nodeName ;
    nodeName = ros::this_node::getName();
    // Create a marker for this node. Only timestamp and position will be later updated.
    marker.header.frame_id = "/map";
    marker.ns = nodeName;
    marker.id = 0;
    marker.type = visualization_msgs::Marker::CUBE;
    marker.action = visualization_msgs::Marker::ADD;
    marker.pose.position.z = 0;
    marker.pose.orientation.x = 0.0;
    marker.pose.orientation.y = 0.0;
    marker.pose.orientation.z = 0.0;
    marker.pose.orientation.w = 1.0;
    marker.scale.x = 0.1;
    marker.scale.y = 0.1;
    marker.scale.z = 0.1;
    marker.color.r = 1.0f;
    marker.color.g = 0.0f;
    marker.color.b = 0.0f;
    marker.color.a = 1.0;
}


// Function to publish a marke at a given (x,y) position.

void publishMarkerAt( geometry_msgs::Point markerPos) {
    marker.header.stamp = ros::Time::now();
    marker.pose.position.x = markerPos.x ;
    marker.pose.position.y = markerPos.y ;
    marker.lifetime = ros::Duration();
    pubMarker.publish(marker);
}


int main (int argc, char** argv)
{

    //ROS Initialization
    ros::init(argc, argv, "dog");

    // Define your node handles
    // Define your node handles
    ros::NodeHandle nh_loc("~") ;
    ros::NodeHandle nh_glob ;

    // Read the node parameters if any
    //initialize the dog position
    dogPose.z = 0;
    nh_loc.param("x_init", dogPose.x, 0.0);
    nh_loc.param("y_init", dogPose.y, 0.0);

    // Declare your node's subscriptions and service clients
    ros::Subscriber subToMasterPose = nh_glob.subscribe<geometry_msgs::Point>("MasterPosition", 1, CalculateDir);
    ros::Subscriber subToMasterVel = nh_glob.subscribe<std_msgs::Float64>("MasterVelocity", 1, UpdateSpeed);

    // Declare you publishers and service servers
    pubMarker = nh_glob.advertise<visualization_msgs::Marker>("/visualization_marker",1) ;
    ros::Publisher positionPub = nh_glob.advertise<geometry_msgs::Point>("DogPosition", 1);
    ros::Publisher velocityPub = nh_glob.advertise<std_msgs::Float64>("DogVelocity", 1);



    // initialize the velocity
    std_msgs::Float64 dogVelocity;
    dogVelocity.data = speed;

    // The direction the dog has to take
    Eigen::VectorXd u(2);
    //the displacement initialization
    Eigen::VectorXd displacement(2);
    displacement(0) = 0;
    displacement(1) = 0;


    // Setting up the marker
    initializeMarker() ;
    publishMarkerAt( dogPose ) ;


    ros::Rate rate(50);   // Or other rate.
    ros::Time currentTime, prevTime = ros::Time::now() ;

    while (ros::ok()){

        ros::spinOnce();

        if(!CalculateDirCalled || !UpdateSpeedCalled)
          continue; //skip any computation untill both callbacks have been called


        // copy dog position
        A(0) = dogPose.x;
        A(1) = dogPose.y;

        //compute the vector
        BA = B - A;

        // compute the direction
        if(BA.norm() > 0.01)  // A threshold to avoid numerical instabilities
          u = BA/BA.norm();
        else {
          u(0) = 0;
          u(1) = 0;
        }

        // Your node's code goes here.
        currentTime = ros::Time::now() ;
        ros::Duration timeElapsed = currentTime - prevTime ;
        prevTime = currentTime ;

        // compute the displacement
        displacement = u*speed*timeElapsed.toSec() ;
        dogPose.x += displacement(0);
        dogPose.y += displacement(1);

        //update the dog speed
        dogVelocity.data = speed;

        // several pushing below this line
        publishMarkerAt( dogPose ) ;
        velocityPub.publish(dogVelocity);
        positionPub.publish(dogPose);

        //wait
        rate.sleep();

    }
}
