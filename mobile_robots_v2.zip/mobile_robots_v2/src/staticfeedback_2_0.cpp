/**
 * \file static StaticFeedback_2_0
 * \brief publish the results of a static feeedback controller for a (2, 0) robot
 * \author Andrea Gotelli
 * \version 0.1
 * \date 6 April 2020
 *
 * \param[in]
 *
 * Subscribes to: <BR>
 *    ° "RobotPose"
 *    ° "TargetOdometry"
 *
 * Publishes to: <BR>
 *    ° "TwistToRobot"
 *
 * Description
 *
 */

#include "mobile_robots_v2/static_feedback_2_0.h"

typedef mobile_robots_v2::StaticFeedbackConfig LocalConfig;

int main(int argc, char** argv)
{
        ros::init(argc, argv, "StaticFeedback_2_0");

        const double d = 0.05;
        const double Kp = 5;

        StaticFeedback_2_0 controller(d, Kp);

        ros::NodeHandle controlNode;

        ros::Subscriber subtoTarget = controlNode.subscribe("TargetOdometry", 1, &Controller::UpdateTargetPosition, dynamic_cast<Controller*>( &controller ));

        ros::Subscriber subtoRobot = controlNode.subscribe("RobotPose", 1, &Controller::UpdateRobotPosition, dynamic_cast<Controller*>( &controller ));

        ros::Publisher twistPublisher = controlNode.advertise<geometry_msgs::Twist>("TwistToRobot", 1);


        //setting the controller frequency
        ros::Rate controllerFrameRate = 100;  //Hz

        //stardard suggested way
        dynamic_reconfigure::Server<LocalConfig> server;

        /*

        //dynamic_reconfigure::Server<mobile_robots_v2::StaticFeedbackConfig>::CallbackType f;
        //<data_type>
        //boost::function< void (mobile_robots_v2::StaticFeedbackConfig &, int) > f2( boost::bind( &StaticFeedback_2_0::SetParameters, &controller, _1, _2 ) );

        The previus signature is the same as:

        boost::function<void (mobile_robots_v2::StaticFeedbackConfig &, int) > f2 = boost::bind( &StaticFeedback_2_0::SetParameters, &controller, _1, _2 ) ;

        Now what is going on is that the second part of the equation is binding the two parameter of the callback.

        The reason of this setting is that the callback function is a void type function: this explay why we have boost::function<void------>

        So here a point to a void function is retuned. Now this void function is taking some parameters

        1)a mobile_robots_v2::StaticFeedbackConfig element as a reference
        2)a uint32_t element.

        So that the pointer to the function is defined as:

        f2 is a pointer to a function with the segniature : void(mobile_robots_v2::StaticFeedbackConfig element&, int)

        so now the pointer is defined. we have to set this pointer equal to something. for that we need to return our callback function

        For this purpose the boost::bind is called, where the two arguments are binded, both the config and the level

        Why?

        Because there is nothing that is passed from this scope, and the function takes automatically what is provided from the
        server callBack

        The previus line can be changed using a lambda function, that makes everything more clear

        the procedure is the same, there is jus an initializer that does not copy anything

        */
        //f = f2;

        dynamic_reconfigure::Server<LocalConfig>::CallbackType f = [&] {

          boost::function< void (LocalConfig &, int) > f2( boost::bind( &StaticFeedback_2_0::SetParameters, &controller, _1, _2 ) );
          return f2;

        } ();


        server.setCallback(f);

        while (ros::ok()) {

          ros::spinOnce();

          controller.ComputeCorrectionTwist();

          twistPublisher.publish(controller.TwistToRobot());

          controllerFrameRate.sleep();

        }


        return 0;
}
