/**
 * \file  circular target node
 * \brief this node publishes a simple reference to follow
 * \author  Andrea Gotelli
 * \version 0.1
 * \date  06 April 2020
 *
 * \param[in] none
 *
 * Subscribes to: <BR>
 *    °
 *
 * Publishes to: <BR>
 *    ° "TargetOdometry" a global topic name that all the robot should follow
 *
 * Description
 *
 */

//CPP
#include <mobile_robots_v2/simulation.h>
#include <mobile_robots_v2/pose.h>



//ROS
#include <ros/ros.h>
#include <nav_msgs/Odometry.h>
#include <visualization_msgs/Marker.h>
#include <dynamic_reconfigure/server.h>
#include <mobile_robots_v2/TargetConfig.h>





double omega;

void callback(mobile_robots_v2::TargetConfig& config, uint32_t level)
{
  omega = config.omega;
}




int main (int argc, char** argv)
{

	//ROS Initialization
  ros::init(argc, argv, "Circulartarget");

  ros::NodeHandle targetNode;

  ros::Publisher targetPublisher = targetNode.advertise<nav_msgs::Odometry>("TargetOdometry", 1);
  ros::Publisher targetToRviz = targetNode.advertise<visualization_msgs::Marker>("TargetToRviz", 1);


  nav_msgs::Odometry targetOdometry;

  ros::Rate targetFrameRate(100);


  const double radius = 4;

  const double t0 = ros::Time::now().toSec();

  targetOdometry.pose.pose.position.z = 1;

  //stardard suggested way
  dynamic_reconfigure::Server<mobile_robots_v2::TargetConfig> server;
  dynamic_reconfigure::Server<mobile_robots_v2::TargetConfig>::CallbackType f;
  f = boost::bind(&callback, _1, _2);
  server.setCallback(f);

  auto targetMarker = sim::TargetMarkerInit();

  while(ros::ok()) {

        ros::spinOnce();

        const double t = ros::Time::now().toSec() - t0;

        targetOdometry.pose.pose.position.x = radius*cos(omega*t);
        targetOdometry.pose.pose.position.y = radius*sin(omega*t);

        targetOdometry.twist.twist.linear.x = -omega*radius*sin(omega*t);
        targetOdometry.twist.twist.linear.y = omega*radius*cos(omega*t);

        targetPublisher.publish(targetOdometry);

        sim::SetCoordinates(Pose(radius*cos(omega*t), radius*sin(omega*t), 1), targetMarker);

        targetToRviz.publish(targetMarker);


        targetFrameRate.sleep();
    }

    return 0;
}
